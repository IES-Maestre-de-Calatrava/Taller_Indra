const API_URL = "http://localhost:8085/personaSimple";

const formCrear = document.getElementById("formCrear");
const tablaPersonas = document.getElementById("tablaPersonas");

const modalEditar = document.getElementById("modalEditar");
const formEditar = document.getElementById("formEditar");
const cerrarModal = document.getElementById("cerrarModal");

document.addEventListener("DOMContentLoaded", cargarPersonas);

formCrear.addEventListener("submit", async (e) => {
  e.preventDefault();

  const persona = {
    nombre: document.getElementById("nombre").value,
    apellidos: document.getElementById("apellidos").value,
    domicilio: document.getElementById("domicilio").value,
    email: document.getElementById("email").value
  };

  try {
    const response = await fetch(`${API_URL}/create`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(persona)
    });

    if (!response.ok) {
      throw new Error("Error al crear la persona");
    }

    formCrear.reset();
    cargarPersonas();
  } catch (error) {
    alert(error.message);
  }
});

async function cargarPersonas() {
  try {
    const response = await fetch(`${API_URL}/find`);

    if (!response.ok) {
      throw new Error("Error al cargar las personas");
    }

    const personas = await response.json();
    pintarTabla(personas);
  } catch (error) {
    alert(error.message);
  }
}

function pintarTabla(personas) {
  tablaPersonas.innerHTML = "";

  personas.forEach((persona) => {
    const fila = document.createElement("tr");

    fila.innerHTML = `
      <td>${persona.id}</td>
      <td>${persona.nombre}</td>
      <td>${persona.apellidos}</td>
      <td>${persona.domicilio || ""}</td>
      <td>${persona.email || ""}</td>
      <td>
        <button class="btn-editar" onclick='abrirModalEditar(${JSON.stringify(persona)})'>
          Editar
        </button>
        <button class="btn-eliminar" onclick="eliminarPersona(${persona.id})">
          Eliminar
        </button>
      </td>
    `;

    tablaPersonas.appendChild(fila);
  });
}

function abrirModalEditar(persona) {
  document.getElementById("editId").value = persona.id;
  document.getElementById("editNombre").value = persona.nombre;
  document.getElementById("editApellidos").value = persona.apellidos;
  document.getElementById("editDomicilio").value = persona.domicilio || "";
  document.getElementById("editEmail").value = persona.email || "";

  modalEditar.classList.remove("oculto");
}

cerrarModal.addEventListener("click", () => {
  modalEditar.classList.add("oculto");
});

formEditar.addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("editId").value;

  const personaEditada = {
    nombre: document.getElementById("editNombre").value,
    apellidos: document.getElementById("editApellidos").value,
    domicilio: document.getElementById("editDomicilio").value,
    email: document.getElementById("editEmail").value
  };

  try {
    const response = await fetch(`${API_URL}/update/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(personaEditada)
    });

    if (!response.ok) {
      throw new Error("Error al editar la persona");
    }

    modalEditar.classList.add("oculto");
    cargarPersonas();
  } catch (error) {
    alert(error.message);
  }
});

async function eliminarPersona(id) {
  const confirmar = confirm("¿Seguro que quieres eliminar esta persona?");

  if (!confirmar) return;

  try {
    const response = await fetch(`${API_URL}/delete/${id}`, {
      method: "DELETE"
    });

    if (!response.ok) {
      throw new Error("Error al eliminar la persona");
    }

    cargarPersonas();
  } catch (error) {
    alert(error.message);
  }
}